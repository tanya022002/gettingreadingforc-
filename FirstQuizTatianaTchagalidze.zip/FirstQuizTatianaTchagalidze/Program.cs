﻿using System;
using FirstQuizTatianaTchagalidze.Properties;

namespace FirstQuizTatianaTchagalidze
{
    public class Program
    {
        static void Main(string[] args)
        {
            var myAge = 21;
            var bankBalance = GenerateRandomBankBalance(1000, 3000);

            Console.WriteLine(bankBalance >= 1000 ? "I have a healthy bank balance!" : "I need to save more.");

            var rect = new Rectangle(10, 20);
            var circ = new Circle(5);

            Console.WriteLine($"Rectangle area: {rect.Area}");
            Console.WriteLine($"Circle area: {circ.Area}");

            var person = new Person("Tatiana Tchagalidze", myAge);
            person.PrintDetails();
        }

        private static double GenerateRandomBankBalance(double min, double max)
        {
            var random = new Random();
            return random.NextDouble() * (max - min) + min;
        }
    }
}
