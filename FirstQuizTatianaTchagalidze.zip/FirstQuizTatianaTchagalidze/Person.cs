using System;

namespace FirstQuizTatianaTchagalidze.Properties
{
    public class Person
    {
        public string Name { get; set; }
        private int age;

        public Person(string name, int age)
        {
            Name = name;
            this.age = age;
        }

        public void PrintDetails()
        {
            Console.WriteLine($"Name: {Name}, Age: {age}");
        }
    }
}
